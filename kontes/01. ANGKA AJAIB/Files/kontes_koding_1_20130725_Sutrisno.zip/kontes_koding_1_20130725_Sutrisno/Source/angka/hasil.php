<?php session_start(); ?>
<p><a href="index.php">MULAI LAGI</a></p>
<?php
$hasil=$_SESSION['hasil'];
$x=1;
$y=1;
$n=1;
if($hasil==0)
	echo '<p>Anda tidak memikirkan angka apapun</p>';
else
{
	echo '<p>Angka yang anda pikirkan adalah = '.$hasil.'</p>';
	echo '<table width="400">'."\n";
	while($x<=4)
	{
		echo "<tr>\n";
		while($y<=8)
		{
			if($n==$hasil)
				echo '<td align="center" bgcolor="#0066FF">'.$n.'</td>'."\n";
			else
				echo '<td align="center">'.$n.'</td>'."\n";
			$y++;
			$n++;
		}
		echo "</tr>\n";
		$x++;
		$y=1;
	}
	echo '</table>'."\n";
}
?>