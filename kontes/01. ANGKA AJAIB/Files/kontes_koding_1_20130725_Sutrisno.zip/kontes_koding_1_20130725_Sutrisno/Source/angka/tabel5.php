<?php session_start();
$pilih=$_GET['pilih'];
if($pilih==0)
	$_SESSION['hasil']=$_SESSION['hasil']+0;
else
	$_SESSION['hasil']=$_SESSION['hasil']+8;
?>
<p>Apakah Angka yang anda pikirkan ada dalam tabel ini ?</p>
<table width="200">
  <tr>
    <td align="center">16</td>
    <td align="center">17</td>
    <td align="center">18</td>
    <td align="center">19</td>
    </tr>
  <tr>
    <td align="center">20</td>
    <td align="center">21</td>
    <td align="center">22</td>
    <td align="center">23</td>
    </tr>
  <tr>
    <td align="center">24</td>
    <td align="center">25</td>
    <td align="center">26</td>
    <td align="center">27</td>
    </tr>
  <tr>
    <td align="center">28</td>
    <td align="center">29</td>
    <td align="center">30</td>
    <td align="center">31</td>
    </tr>
</table>
<div class="action"><span onclick="proses('status.php?pilih=1')" class="btn">YA</span> | <span onclick="proses('status.php?pilih=0')" class="btn">TIDAK</span></div>