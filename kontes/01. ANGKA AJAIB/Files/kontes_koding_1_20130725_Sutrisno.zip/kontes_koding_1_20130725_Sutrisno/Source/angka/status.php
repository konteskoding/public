<?php session_start();
$pilih=$_GET['pilih'];
if($pilih==0)
	$_SESSION['hasil']=$_SESSION['hasil']+0;
else
	$_SESSION['hasil']=$_SESSION['hasil']+16;
?>
<p>Angka yang anda pilih dapat dilihat <span onclick="proses('hasil')" class="btn">Disini</span></p>