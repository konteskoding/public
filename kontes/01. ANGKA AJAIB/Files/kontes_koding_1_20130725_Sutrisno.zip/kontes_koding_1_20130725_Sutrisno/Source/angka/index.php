<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Angka Ajaib</title>
<script src="jquery-1.10.2.min.js" type="text/javascript"></script>
<script type="text/javascript">
function proses(url){
	$('#main').slideUp('slow');
	$('#loading').fadeIn('slow');
	setTimeout('tampil("'+url+'")', 2000);
}

function tampil(url){
	$('#loading').fadeOut('slow');
	$('#main').load(url);
	$('#main').slideDown('slow');
}
</script>
<style>
*{
	padding: 0;
	margin: 0;
}
.btn{
	color: #FFF;
	cursor: pointer;
	background: #02A1FC;
	padding: 5px 10px;
	transition: background 0.7s;
}
.btn:hover{
	background: #0F38AF;
}
.bg{
	background: #222;
	font-family: Arial, Helvetica, sans-serif;
	font-size: small;
}
.content{
	background: #EEE;
	width: 500px;
	padding-bottom: 20px;
	border-top: 8px double #111;
	border-bottom: 8px double #111;
	margin-top: 30px;
}
.content h1{
	background: #333;
	color: #FFF;
	margin-bottom: 10px;
	padding: 5px 0;
}
#loading{
	display: none;
}
.content h{
	background: #333;
	color: #FFF;
	margin-bottom: 10px;
	padding: 5px 0;
}
.action{
	margin-top: 20px;
}
table{
	border: 1px solid #000;
	margin: 10px 0;
}
table td{
	border-left: 1px solid #000;
	border-bottom: 1px solid #000;
	padding: 8px;
}
table td:first-child{
	border-left: none;
}
table tr:last-child td{
	border-bottom: none;
}
</style>
</head>

<body class="bg">
<div align="center">

<div class="content">
<h1>Angka Ajaib</h1>
<div id="main">
  <p><strong>Aturan Main</strong> : Pikirkan satu angka dari 1 - 32 lalu klik mulai</p>
  <table width="400">
  <tr>
    <td align="center">1</td>
    <td align="center">2</td>
    <td align="center">3</td>
    <td align="center">4</td>
    <td align="center">5</td>
    <td align="center">6</td>
    <td align="center">7</td>
    <td align="center">8</td>
  </tr>
  <tr>
    <td align="center">9</td>
    <td align="center">10</td>
    <td align="center">11</td>
    <td align="center">12</td>
    <td align="center">13</td>
    <td align="center">14</td>
    <td align="center">15</td>
    <td align="center">16</td>
  </tr>
  <tr>
    <td align="center">17</td>
    <td align="center">18</td>
    <td align="center">19</td>
    <td align="center">20</td>
    <td align="center">21</td>
    <td align="center">22</td>
    <td align="center">23</td>
    <td align="center">24</td>
  </tr>
  <tr>
    <td align="center">25</td>
    <td align="center">26</td>
    <td align="center">27</td>
    <td align="center">28</td>
    <td align="center">29</td>
    <td align="center">30</td>
    <td align="center">31</td>
    <td align="center">32</td>
  </tr>
</table>
  <div class="action"><span onclick="proses('tabel1.php')" class="btn">MULAI</span></div>
</div>
<img src="loading.gif" width="220" height="19" alt="loading" id="loading" />
</div>

</div>
</body>
</html>