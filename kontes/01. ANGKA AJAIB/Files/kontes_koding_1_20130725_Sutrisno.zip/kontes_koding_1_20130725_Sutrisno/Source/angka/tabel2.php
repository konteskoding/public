<?php session_start();
$pilih=$_GET['pilih'];
if($pilih==0)
	$_SESSION['hasil']=$_SESSION['hasil']+0;
else
	$_SESSION['hasil']=$_SESSION['hasil']+1;
?>
<p>Apakah Angka yang anda pikirkan ada dalam tabel ini ?</p>
<table width="200">
  <tr>
    <td align="center">2</td>
    <td align="center">3</td>
    <td align="center">6</td>
    <td align="center">7</td>
    </tr>
  <tr>
    <td align="center">10</td>
    <td align="center">11</td>
    <td align="center">14</td>
    <td align="center">15</td>
    </tr>
  <tr>
    <td align="center">18</td>
    <td align="center">19</td>
    <td align="center">22</td>
    <td align="center">23</td>
    </tr>
  <tr>
    <td align="center">26</td>
    <td align="center">27</td>
    <td align="center">30</td>
    <td align="center">31</td>
    </tr>
</table>
<div class="action"><span onclick="proses('tabel3.php?pilih=1')" class="btn">YA</span> | <span onclick="proses('tabel3.php?pilih=0')" class="btn">TIDAK</span></div>