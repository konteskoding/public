<?php session_start();
$_SESSION['hasil']=0;
$_SESSION['hasil']=0;
?>
<div class="hidden">
<p>Apakah Angka yang anda pikirkan ada dalam tabel ini ?</p>
<table width="200">
  <tr>
    <td align="center">1</td>
    <td align="center">3</td>
    <td align="center">5</td>
    <td align="center">7</td>
    </tr>
  <tr>
    <td align="center">9</td>
    <td align="center">11</td>
    <td align="center">13</td>
    <td align="center">15</td>
    </tr>
  <tr>
    <td align="center">17</td>
    <td align="center">19</td>
    <td align="center">21</td>
    <td align="center">23</td>
    </tr>
  <tr>
    <td align="center">25</td>
    <td align="center">27</td>
    <td align="center">29</td>
    <td align="center">31</td>
    </tr>
</table>
<div class="action"><span onclick="proses('tabel2.php?pilih=1')" class="btn">YA</span> | <span onclick="proses('tabel2.php?pilih=0')" class="btn">TIDAK</span></div>
</div>