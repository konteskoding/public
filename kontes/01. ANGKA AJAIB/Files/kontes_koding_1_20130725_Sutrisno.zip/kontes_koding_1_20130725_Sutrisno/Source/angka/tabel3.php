<?php session_start();
$pilih=$_GET['pilih'];
if($pilih==0)
	$_SESSION['hasil']=$_SESSION['hasil']+0;
else
	$_SESSION['hasil']=$_SESSION['hasil']+2;
?>
<p>Apakah Angka yang anda pikirkan ada dalam tabel ini ?</p>
<table width="200">
  <tr>
    <td align="center">4</td>
    <td align="center">5</td>
    <td align="center">6</td>
    <td align="center">7</td>
    </tr>
  <tr>
    <td align="center">12</td>
    <td align="center">13</td>
    <td align="center">14</td>
    <td align="center">15</td>
    </tr>
  <tr>
    <td align="center">20</td>
    <td align="center">21</td>
    <td align="center">22</td>
    <td align="center">23</td>
    </tr>
  <tr>
    <td align="center">28</td>
    <td align="center">29</td>
    <td align="center">30</td>
    <td align="center">31</td>
    </tr>
</table>
<div class="action"><span onclick="proses('tabel4.php?pilih=1')" class="btn">YA</span> | <span onclick="proses('tabel4.php?pilih=0')" class="btn">TIDAK</span></div>