import java.util.Scanner;
import java.util.Vector;

class TableGenerator{
	
	private static int total=0;
	
	public static void main(String args[]){
		System.out.println("Choose any number between 1-31 and answer these questions below.\n");
		setTable();		
	}
	
	private static String getInputFromUser(){
		System.out.print("Is your number on the table? (Y/N): ");
		Scanner scanner = new Scanner(System.in);
		return scanner.next();
	}
	
	private static void setCalculationTableIndex(int index){
		total+=index;
	}
	
	private static void setTable(){	
		@SuppressWarnings("unchecked")
		Vector<Integer>[] vTable = new Vector[5];
		for(int i=0;i<vTable.length;i++){
			vTable[i] = new Vector<Integer>();
			int firstElementOfTable = (int) Math.pow(2, i);
			setElementOfTable(i, vTable[i], firstElementOfTable);
			printTable(vTable[i]);
			if(getInputFromUser().toLowerCase().equals("y"))
				setCalculationTableIndex(firstElementOfTable);
		}		
		System.out.println("Your number is: "+total);
	}
	
	private static void setElementOfTable(int indexTable, Vector<Integer> v, int number){
		if(v.size()<16){
			v.addElement(number);
			
			if(indexTable==0)//table 1
				number+=2;
			else if(indexTable==1){//table 2
				if(number%2==0)
					number+=1;
				else
					number+=3;
			} 
			else if(indexTable==2){//table 4
				if(v.size()%4==0)
					number+=5;
				else
					number+=1;
			} 
			else if(indexTable==3){//table 8
				if(v.size()%8==0)
					number+=9;
				else
					number+=1;
			}
			else//table 16
				number+=1;

			setElementOfTable(indexTable, v, number);
		}	
	}
	
	private static void printTable(Vector<Integer> v){
		int j=1;
		for(int i=0;i<v.size();i++){
			if(j%4==0)
				System.out.println(v.elementAt(i));
			else{
				if(v.elementAt(i)>9)
					System.out.print(v.elementAt(i)+" ");
				else
					System.out.print(v.elementAt(i)+"  ");
			}
			j++;
		}
		System.out.println("-----------------------------------");
	}	
}