//---------------------------------------------------------------------------

#ifndef uMainH
#define uMainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Graphics.hpp>
#include <ImgList.hpp>
#include <Menus.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TfrmMain : public TForm
{
__published:	// IDE-managed Components
        TImage *Image1;
        TImage *Tabel;
        TImage *Tabel1;
        TImage *Tabel2;
        TImage *Tabel4;
        TImage *Tabel8;
        TImage *Tabel16;
        TLabel *Label1;
        TLabel *nama;
        TLabel *Label2;
        TLabel *Label3;
        TLabel *Label4;
        TButton *Mulai;
        TLabel *Label5;
        TLabel *Label6;
        TLabel *Label7;
        TLabel *Label8;
        TButton *Sudah;
        TButton *Button1;
        TBitBtn *btnAda;
        TBitBtn *btnTidak;
        TMainMenu *MainMenu1;
        TLabel *Label9;
        TMenuItem *Menu1;
        TMenuItem *MulaiBaru1;
        TMenuItem *Keluar1;
        TMenuItem *About1;
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall MulaiClick(TObject *Sender);
        void __fastcall btnAdaClick(TObject *Sender);
        void __fastcall btnTidakClick(TObject *Sender);
        void __fastcall SudahClick(TObject *Sender);
        void __fastcall MulaiBaru1Click(TObject *Sender);
        void __fastcall Keluar1Click(TObject *Sender);
        void __fastcall About1Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TfrmMain(TComponent* Owner);
        void __fastcall Rumus();
        void __fastcall Baru();
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmMain *frmMain;
//---------------------------------------------------------------------------
#endif
