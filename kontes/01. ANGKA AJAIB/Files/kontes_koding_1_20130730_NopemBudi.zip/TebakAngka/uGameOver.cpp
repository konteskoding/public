//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "uGameOver.h"
#include "uMain.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfrmGameOver *frmGameOver;
//---------------------------------------------------------------------------
__fastcall TfrmGameOver::TfrmGameOver(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TfrmGameOver::btnNewClick(TObject *Sender)
{
        Close();
        frmMain->Baru();        
}
//---------------------------------------------------------------------------

void __fastcall TfrmGameOver::FormShow(TObject *Sender)
{
        frmMain->Enabled = False;        
}
//---------------------------------------------------------------------------

void __fastcall TfrmGameOver::FormClose(TObject *Sender,
      TCloseAction &Action)
{
        frmMain->Enabled = True;        
}
//---------------------------------------------------------------------------

void __fastcall TfrmGameOver::Button1Click(TObject *Sender)
{
        frmGameOver->Close();
        frmMain->Close();
}
//---------------------------------------------------------------------------

