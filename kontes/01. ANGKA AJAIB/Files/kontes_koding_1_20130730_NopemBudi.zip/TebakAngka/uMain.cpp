//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "uMain.h"
#include "uGameOver.h"
#include "uAbout.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfrmMain *frmMain;
 int G=1, a,b,d,h,p, Hasil;
//---------------------------------------------------------------------------
__fastcall TfrmMain::TfrmMain(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::FormCreate(TObject *Sender)
{
        char NAMA[MAX_COMPUTERNAME_LENGTH + 1];
        DWORD SIZE = MAX_COMPUTERNAME_LENGTH + 1;

        GetComputerName(NAMA, &SIZE);

        nama->Caption = AnsiStrLower(NAMA);
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::MulaiClick(TObject *Sender)
{
        Baru();
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::Rumus(void)
{
        Hasil = a+b+d+h+p;
        frmGameOver->lblAngka->Caption = Hasil;
        if (Hasil == 0)
                frmGameOver->lblAngka->Caption = 32;
}
//---------------------------------------------------------------------------



void __fastcall TfrmMain::btnAdaClick(TObject *Sender)
{
        if(G==1)
                {G = 2;
                Tabel->Picture = Tabel2->Picture;
                a=1;
                Label9->Caption = "kalau di sini?? ";}
        else if(G==2)
                {G = 4;
                Tabel->Picture = Tabel4->Picture;
                b=2;
                Label9->Caption = "Coba cek yang ini?? ";}
        else if(G==4)
                {G = 8;
                Tabel->Picture = Tabel8->Picture;
                d=4;
                Label9->Caption = "Bagaimana yang ini?? ";}
        else if(G==8)
                {G = 16;
                Tabel->Picture = Tabel16->Picture;
                h=8;
                Label9->Caption = "Ini yang terakhir... ";}
        else
                {G = 16;
                Tabel->Picture = Tabel16->Picture;
                p=16;
                Rumus();
                frmGameOver->Position = poMainFormCenter;
                frmGameOver->Show();}
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::btnTidakClick(TObject *Sender)
{
        if(G==1)
                {G = 2;
                Tabel->Picture = Tabel2->Picture;
                a=0;
                Label9->Caption = "Kalau di sini?? ";}
        else if(G==2)
                {G = 4;
                Tabel->Picture = Tabel4->Picture;
                b=0;
                Label9->Caption = "Coba cek yang ini?? ";}
        else if(G==4)
                {G = 8;
                Tabel->Picture = Tabel8->Picture;
                d=0;
                Label9->Caption = "Bagaimana yang ini?? ";}
        else if(G==8)
                {G = 16;
                Tabel->Picture = Tabel16->Picture;
                h=0;
                Label9->Caption = "Ini yang terakhir... ";}
        else
                {G = 16;
                Tabel->Picture = Tabel16->Picture;
                p=0;
                Rumus();
                frmGameOver->Position = poMainFormCenter;
                frmGameOver->Show();}
}
//---------------------------------------------------------------------------


void __fastcall TfrmMain::SudahClick(TObject *Sender)
{
        Label5->Visible = False;
        Label6->Visible = False;
        Label7->Visible = False;
        Label9->Visible = True;

        Sudah->Visible = False;
        btnAda->Visible = True;
        btnTidak->Visible = True;
        Tabel->Visible = True;
}
//---------------------------------------------------------------------------


void __fastcall TfrmMain::MulaiBaru1Click(TObject *Sender)
{
        Baru();
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::Baru(void)
{
        Label5->Visible = True;
        Label6->Visible = True;
        Label7->Visible = True;
        Label9->Visible = False;

        btnAda->Visible = False;
        btnTidak->Visible = False;
        Tabel->Visible = False;

        Label1->Visible = False;
        Label2->Visible = False;
        Label3->Visible = False;
        Label4->Visible = False;
        nama->Visible = False;
        Mulai->Visible = False;
        Sudah->Visible = True;

        Label5->Left = 32;
        Label5->Top = 48;
        Label6->Left = 16;
        Label6->Top = 88;
        Label7->Left = 32;
        Label7->Top =128;

        Tabel->Picture = Tabel1->Picture;
        Label9->Caption = "Apakah ada di sini?? ";
        G = 1;
        a=0; b=0; d=0; h=0; p=0; Hasil=0;
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::Keluar1Click(TObject *Sender)
{
        frmGameOver->Close();
        frmMain->Close();        
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::About1Click(TObject *Sender)
{
        frmAbout->Position = poMainFormCenter;
        frmAbout->Show();
}
//---------------------------------------------------------------------------

