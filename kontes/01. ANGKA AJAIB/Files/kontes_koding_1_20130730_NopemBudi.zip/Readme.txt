Program Tebak Angka
Berbahasa Indosesia

Bibuat menggunakan aplikasi Borland C++ Builder 6

Oleh;
Nama		: Nopem Budi
E-mail		: noven.cisco@gmail.com

facebook	: Noven Budi Technician
twitter		: @NovenBudi