Programmer
Nama Asli : Muchammad Aly mBA
Nick Name : Abdellah Al-'Arief, mambamaestro
Email : marketing@altaifa.com
Facebook: www.facebook.com/mambamaestro/
Twitter : mambamaestro
Language : FreePascal 
IDE : Typhon IDE / Lazarus 
Note : kemungkinan dengan IDE Lazarus default (tidak pakai typhon IDE), source code tetap dapat dibuka. 
      karena saya menggunakan komponen standard.