Nama : Picho Endo
Email : picho.endo@yahoo.com
Bahasa : Actionscript 2
Twiterr : -
Facebook :http://www.facebook.com/mindmycode
Revisi penambahan screenshot