<?php
session_start();

# Script By Nanang Haris S
# nanank.haries@gmail.com

# Jika direset, session dihapus. Kembalikan ke tab3l 1
if( isset($_POST['reset']) ){
	unset($_SESSION['game']);
}

# Jika pilih go
if( isset($_POST['post']) )
{
	
	# Apabila guest belum memilih opsi
	if( !isset($_POST['in_here']) )
	{
		$msg = "Anda belum memilih opsi";
	}
	else
	{
	
		$in_here = (int)$_POST['in_here'];
		$in_table = (int)$_POST['current_table'];		
		
		# Current tabel diambil dari index array $table dikalikan 2
		# Apabila guest memilih iya, masukkan posisi tabel ke dalam Array session.
		$_SESSION['game']['current_table'] = ($in_table*2);
		if( $in_here == 1 )
		{
			$_SESSION['game']['current_num'][] = $in_table; 	
		}
		
		$hasil = 0;
		
		# Apabila guest sudah berada ditabel terakhir
		if( isset($_POST['end_table']) )
		{
			# Cek, apabila sessionnya sudah habis, kembalikan ke tabel 1
			if( !isset($_SESSION['game']['current_num']) ){
				header('location:index.php');	
			}
			
			# Result : karena variable $_SESSION['game']['current_num'] berupa array yang menyimpan data diposisi tabel berapa guest memilih opsi iya
			# ambil data array-nya kemudian jumlahkan
			foreach((array)$_SESSION['game']['current_num'] as $nilai)
			{
				$hasil += $nilai;
			}
			
			$result = (int)$hasil;
			unset($_SESSION['game']);
			
		}
	}
	
}


# Data tabel
$table = array();
$table[1] = array(1,3,5,7,9,11,13,15,17,19,21,23,25,17,19,31);
$table[2] = array(2,3,6,7,10,11,14,15,18,19,22,23,26,27,30,31);
$table[4] = array(4,5,6,7,12,13,14,15,20,21,22,23,28,29,30,31);
$table[8] = array(8,9,10,11,12,13,14,15,24,25,26,27,28,29,30,31);
$table[16] = array(16,17,18,19,20,12,22,23,24,25,26,27,28,29,30,31);

$curent_table = 1;
if( isset($_SESSION['game']['current_table']) or !empty($_SESSION['game']['current_table']) ){
	$curent_table = (int)$_SESSION['game']['current_table'];	
}
