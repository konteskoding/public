<?php include 'action.php'; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Kontes Koding Game</title>
<style type="text/css">
<!--
@import url("style.css");
-->
</style>
</head>
<body>

<form method="post" action="">
<?php if( !isset($result) ) :	?>
    <table id="background-image" summary="Kontes Koding Game">
    	<thead>
            <tr class="tdhead">
                <td colspan="4">Silahkan pikirkan 1 angka antara 1 - 31</td>                
            </tr>            
            <tr class="tdhead">
                <td colspan="4" class="title">TABEL <?php echo $curent_table;?></td>
            </tr>                         
        </thead>
        
        <tbody>
        	<tr>
				<?php 
                    $i=0;
                    foreach((array)$table[$curent_table] as $row):
                    $i++;
                ?>
                    <td class="center"><?php echo $row;?></td>
                    <?php if( $i%4==0 ){ echo '</tr><tr>'; } ?>
                <?php endforeach;?> 
            </tr>
        </tbody>
        
        <tfoot>
            <?php if( isset($msg) ): ?>
            	<tr class="tdhead">
                	<td colspan="4" class="center msg">Warning : <?php echo $msg; ?></td>
            	</tr>
            <?php endif; ?> 
           <tr>
               <td colspan="4" class="tdhead">
               Apakah nomor yang Anda pikirkan ada ditabel ini?<br>
                <input type="radio" name="in_here" value="1" id="yes"><label for="yes">Iya</label><br>
                <input type="radio" name="in_here" value="0" id="no"><label for="no">Tidak</label>
               </td>
           </tr>
           <tr>
               <td colspan="4" class="tdhead">
               <?php if(  $curent_table == 16 ) : ?>
                    <input type="hidden" name="end_table" value="1">
                <?php endif; ?>
                <input type="hidden" name="current_table" value="<?php echo $curent_table;?>">
                <input type="submit" name="post" value="Go" class="button yellow">
                <input type="submit" name="reset" value="Reset" class="button yellow">
               </td>
           </tr>
        </tfoot>
        
    </table>
    
    <?php else: ?>
    <table id="background-image" summary="Kontes Koding Game">
    <thead>
        <tr class="tdhead">
            <td colspan="4">Anda memilih angka : </td>                
        </tr>                               
    </thead>
    
    <tbody>
    	<td colspan="4"><h2><?php echo $result;?></h2></td>
    </tbody>
    
    <tfoot>
    	<td colspan="4" class="tdhead">
        	<input type="submit" name="reset" value="Main lagi" class="button yellow">
        </td>
    </tfoot>
    
    </table>    
    <?php endif; ?>
    
</form>



</body>
</html>