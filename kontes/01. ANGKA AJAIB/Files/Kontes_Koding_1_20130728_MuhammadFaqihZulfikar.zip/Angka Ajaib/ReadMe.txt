Nama	: Muhammad Faqih Zulfikar
Email	: muhammadfaqih54@yahoo.co.id
Twitter	: @FaqihZulfikar
Bahasa	: C / C++ (Borland C++ Builder6)
Facebook: www.facebook.com/DorkSQLi

Untuk folder system32 isi filenya silahkan copy dan paste ke C:/WINDOWS/system32