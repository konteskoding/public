//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------


void __fastcall TForm1::Label4Click(TObject *Sender)
{
Panel1->Visible = false;
Panel2->Visible = true;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Label11Click(TObject *Sender)
{
Panel2->Visible = false;
Panel3->Visible = true;
//ShowMessage(OK->Caption);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Label10Click(TObject *Sender)
{
OK->Caption =+1;
Panel2->Visible = false;
Panel3->Visible = true;
//ShowMessage(OK->Caption);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Label13Click(TObject *Sender)
{
OK->Caption =(OK->Caption*1)+2;
Panel3->Visible = false;
Panel4->Visible = true;
//ShowMessage(OK->Caption);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Label12Click(TObject *Sender)
{
Panel3->Visible = false;
Panel4->Visible = true;
//ShowMessage(OK->Caption);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Label24Click(TObject *Sender)
{
OK->Caption = (OK->Caption*1)+4;
Panel4->Visible = false;
Panel5->Visible = true;
//ShowMessage(OK->Caption);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Label25Click(TObject *Sender)
{
Panel4->Visible = false;
Panel5->Visible = true;
//ShowMessage(OK->Caption);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Label31Click(TObject *Sender)
{
OK->Caption = (OK->Caption*1)+8;
Panel5->Visible = false;
Panel6->Visible = true;
//ShowMessage(OK->Caption);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Label32Click(TObject *Sender)
{
Panel5->Visible = false;
Panel6->Visible = true;
//ShowMessage(OK->Caption);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Label38Click(TObject *Sender)
{
OK->Caption = (OK->Caption*1)+16;
Panel6->Visible = false;
//ShowMessage(OK->Caption);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Label39Click(TObject *Sender)
{
Panel6->Visible = false;
//ShowMessage(OK->Caption);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Timer1Timer(TObject *Sender)
{
if(OK->Enabled == true)
 {
 OK->Enabled = false;
 }
else if(OK->Enabled == false)
 {
 OK->Enabled = true;
 }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Label41Click(TObject *Sender)
{
Panel1->Visible = true;
}
//---------------------------------------------------------------------------

