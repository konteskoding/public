//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TPanel *Panel1;
        TLabel *Label1;
        TLabel *Label2;
        TLabel *Label3;
        TLabel *Label4;
        TPanel *Panel2;
        TLabel *Label5;
        TLabel *Label6;
        TLabel *Label7;
        TLabel *Label8;
        TLabel *Label9;
        TLabel *Label10;
        TLabel *Label11;
        TLabel *OK;
        TPanel *Panel3;
        TLabel *Label12;
        TLabel *Label13;
        TLabel *Label14;
        TLabel *Label15;
        TLabel *Label16;
        TLabel *Label17;
        TLabel *Label18;
        TPanel *Panel4;
        TLabel *Label19;
        TLabel *Label20;
        TLabel *Label21;
        TLabel *Label22;
        TLabel *Label23;
        TLabel *Label24;
        TLabel *Label25;
        TPanel *Panel5;
        TLabel *Label26;
        TLabel *Label27;
        TLabel *Label28;
        TLabel *Label29;
        TLabel *Label30;
        TLabel *Label31;
        TLabel *Label32;
        TPanel *Panel6;
        TLabel *Label33;
        TLabel *Label34;
        TLabel *Label35;
        TLabel *Label36;
        TLabel *Label37;
        TLabel *Label38;
        TLabel *Label39;
        TLabel *Label40;
        TTimer *Timer1;
        TLabel *Label41;
        void __fastcall Label4Click(TObject *Sender);
        void __fastcall Label11Click(TObject *Sender);
        void __fastcall Label10Click(TObject *Sender);
        void __fastcall Label13Click(TObject *Sender);
        void __fastcall Label12Click(TObject *Sender);
        void __fastcall Label24Click(TObject *Sender);
        void __fastcall Label25Click(TObject *Sender);
        void __fastcall Label31Click(TObject *Sender);
        void __fastcall Label32Click(TObject *Sender);
        void __fastcall Label38Click(TObject *Sender);
        void __fastcall Label39Click(TObject *Sender);
        void __fastcall Timer1Timer(TObject *Sender);
        void __fastcall Label41Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
