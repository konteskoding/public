Nama 	: David Senjaya
Email 	: davidsenjayagm@gmail.com
Twitter : @david_senjaya
Bahasa 	: Java