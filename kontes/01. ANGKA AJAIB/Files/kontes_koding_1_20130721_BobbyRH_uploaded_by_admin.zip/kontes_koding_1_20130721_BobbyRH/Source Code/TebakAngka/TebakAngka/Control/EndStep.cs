﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Media;

namespace TebakAngka.Control
{
    class EndStep:IStep
    {
        private String partnerDialog = "Pak Burung tau berapa angka yang kamu pikirkan..Benarkan???";

        private String lblDialog = "Angka yang kamu pikirkan adalah ";

        private int result = 0;

        public void playSound()
        {
            try
            {
                SoundPlayer splayer = new SoundPlayer(TebakAngka.Properties.Resources.resultDialog);
                splayer.Play();
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex);
            }

        }

        public int getConstantaCount()
        {
            return 0;
        }
        public void countResult(List<int> cons)
        {
            result = cons.Sum();
            Debug.WriteLine("============+");
            foreach (int x in cons)
            {
                Debug.WriteLine(x);
            }
            Debug.WriteLine("============+");
            Debug.WriteLine(cons.Sum());
        }

        public void setPartnerDialogText(TextBox field)
        {
            field.Text = partnerDialog;
        }
        public Boolean generateNumberInBox(TableLayoutPanel table)
        {
            return true;
        }
        public void setMainDialog(Label lbl)
        {
            lbl.Text = lblDialog+result;
            result = 0;
        }
    }
}
