﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Drawing;
using System.Media;

namespace TebakAngka.Control
{
    class Step2:IStep
    {
        private String partnerDialog = "Apakah angka yang dipilih ada di tabel berikut?";

        private String lblDialog = "";

        private int[] number = new int[] { 2,3,6,7,10,11,14,15,18,19,22,23,26,27,30,31 };

        public int constantaCount = 2;
        private const int rowLimit = 4;
        private const int colLimit = 4;

        public void playSound()
        {
            try
            {
                SoundPlayer splayer = new SoundPlayer(TebakAngka.Properties.Resources.ongoingDialog);
                splayer.Play();
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex);
            }

        }

        public void countResult(List<int> cons)
        {

        }

        public int getConstantaCount()
        {
            return constantaCount;
        }
        public void setPartnerDialogText(TextBox field)
        {
            field.Text = partnerDialog;
        }

        public Boolean generateNumberInBox(TableLayoutPanel table)
        {
            Boolean retval = false;
            Label[] lbl = new Label[number.Length];
            int numberCounter = 0;
            int row = 0;

            for (int i = 0; i < number.Length; i++)
            {
                lbl[i] = new Label();
                lbl[i].TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
                lbl[i].Text = number[i].ToString();
            }

            try
            {
                table.Controls.Clear();
                table.ColumnStyles.Clear();
                table.RowStyles.Clear();
                table.ColumnCount = colLimit;
                table.RowCount = rowLimit;

                do
                {
                    table.RowStyles.Add(new RowStyle(SizeType.Percent, 50.0F));
                    table.Controls.Add(lbl[numberCounter], row, 0);
                    for (int column = 0; column < colLimit; column++)
                    {
                        table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50.0F));
                        lbl[numberCounter].AutoSize = true;
                        lbl[numberCounter].Font = new Font(lbl[numberCounter].Font.FontFamily.Name, 20, FontStyle.Bold);
                        table.Controls.Add(lbl[numberCounter], column, row);
                        numberCounter++;
                    }
                    row++;
                }
                while (numberCounter < number.Length || row < rowLimit);

                retval = true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex);
            }

            return retval;
        }

        public void setMainDialog(Label lbl)
        {
            lbl.Text = lblDialog;
        }
    }
}
