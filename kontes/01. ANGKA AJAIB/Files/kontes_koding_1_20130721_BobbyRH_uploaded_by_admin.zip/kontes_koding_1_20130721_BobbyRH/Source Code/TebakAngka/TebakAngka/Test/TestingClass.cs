﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TebakAngka.Control;
using System.Diagnostics;
using System.Windows.Forms;

namespace TebakAngka.Test
{
    class TestingClass
    {
        StepCollection col = new StepCollection();

        public TestingClass()
        {
            Console.WriteLine("Test Class Begin");
        }

        public void startTest()
        {
            //Console.WriteLine("prev "+col.getPrevStep());
            //Console.WriteLine("curr "+col.getCurrStep());
            Console.WriteLine("next "+col.getNextStep());
            Console.WriteLine("next " + col.getNextStep());
            Console.WriteLine("next " + col.getNextStep());
            Console.WriteLine();


           // Console.WriteLine("curr " + col.getCurrStep());
            Console.WriteLine("prev " + col.getPrevStep());
            Console.WriteLine("prev " + col.getPrevStep());
            Console.WriteLine("next " + col.getNextStep());
            Console.WriteLine("next " + col.getNextStep());
            Console.WriteLine("next " + col.getNextStep());
            Console.WriteLine("next " + col.getNextStep());
            Console.WriteLine("next " + col.getNextStep());
            Console.WriteLine("prev " + col.getPrevStep());
        }

    }
}
