﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TebakAngka.GUI
{
    public partial class AboutForm : Form
    {
        private String strAbout = "Aplikasi ini bertujuan untuk learning dan submit entry "+
            "untuk http://programminglearning.wordpress.com/2013/07/18/lomba-membuat-game-sederhana-sesuai-contoh-level-pemula/ "+
            "aplikasi ini dibuat sedinamis mungkin sehingga mudah dikembangkan kemudian"+System.Environment.NewLine+System.Environment.NewLine+
            "Credit of code goes to God, myself, and google" + System.Environment.NewLine+
            "Credit of image goes to http://kyo-tux.deviantart.com"+ System.Environment.NewLine+
            "Credit of logo goes to http://cooltext.com" + System.Environment.NewLine +
            "Credit of WAV sound recorder goes to www.naturpic.com/all2wav" + System.Environment.NewLine + System.Environment.NewLine +
            "#Bobby H - 2013";

        public AboutForm()
        {
            InitializeComponent();
            this.aboutLbl.Text = strAbout;
        }
    }
}
