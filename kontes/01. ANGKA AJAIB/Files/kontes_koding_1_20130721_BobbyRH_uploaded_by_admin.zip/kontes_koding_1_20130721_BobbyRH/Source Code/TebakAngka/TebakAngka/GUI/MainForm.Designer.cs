﻿namespace TebakAngka
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.s = new System.Windows.Forms.Panel();
            this.resetBtn = new System.Windows.Forms.Button();
            this.mulaiBtn = new System.Windows.Forms.Button();
            this.mainLabel = new System.Windows.Forms.Label();
            this.tdkAdaBtn = new System.Windows.Forms.Button();
            this.adaBtn = new System.Windows.Forms.Button();
            this.tableNumber = new System.Windows.Forms.TableLayoutPanel();
            this.partnerGroupBox = new System.Windows.Forms.GroupBox();
            this.partnerTextBox = new System.Windows.Forms.TextBox();
            this.aboutBtn = new System.Windows.Forms.Button();
            this.logoPanel = new System.Windows.Forms.Panel();
            this.partnerPanel = new System.Windows.Forms.Panel();
            this.s.SuspendLayout();
            this.partnerGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // s
            // 
            this.s.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.s.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.s.Controls.Add(this.resetBtn);
            this.s.Controls.Add(this.mulaiBtn);
            this.s.Controls.Add(this.mainLabel);
            this.s.Controls.Add(this.tdkAdaBtn);
            this.s.Controls.Add(this.adaBtn);
            this.s.Controls.Add(this.tableNumber);
            this.s.Location = new System.Drawing.Point(12, 125);
            this.s.Name = "s";
            this.s.Size = new System.Drawing.Size(453, 342);
            this.s.TabIndex = 4;
            // 
            // resetBtn
            // 
            this.resetBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resetBtn.Location = new System.Drawing.Point(267, 21);
            this.resetBtn.Name = "resetBtn";
            this.resetBtn.Size = new System.Drawing.Size(159, 44);
            this.resetBtn.TabIndex = 5;
            this.resetBtn.Text = "Balik awal lagi ah !!";
            this.resetBtn.UseVisualStyleBackColor = true;
            this.resetBtn.Click += new System.EventHandler(this.resetBtn_Click);
            // 
            // mulaiBtn
            // 
            this.mulaiBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mulaiBtn.Image = global::TebakAngka.Properties.Resources.Forward;
            this.mulaiBtn.Location = new System.Drawing.Point(287, 237);
            this.mulaiBtn.Name = "mulaiBtn";
            this.mulaiBtn.Size = new System.Drawing.Size(139, 100);
            this.mulaiBtn.TabIndex = 4;
            this.mulaiBtn.Text = "MAIN (LAGI) !!!";
            this.mulaiBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.mulaiBtn.UseVisualStyleBackColor = true;
            this.mulaiBtn.Click += new System.EventHandler(this.mulaiBtn_Click);
            // 
            // mainLabel
            // 
            this.mainLabel.BackColor = System.Drawing.SystemColors.HighlightText;
            this.mainLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mainLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mainLabel.Location = new System.Drawing.Point(14, 68);
            this.mainLabel.Name = "mainLabel";
            this.mainLabel.Size = new System.Drawing.Size(412, 153);
            this.mainLabel.TabIndex = 3;
            // 
            // tdkAdaBtn
            // 
            this.tdkAdaBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tdkAdaBtn.Image = global::TebakAngka.Properties.Resources.Stop;
            this.tdkAdaBtn.Location = new System.Drawing.Point(136, 237);
            this.tdkAdaBtn.Name = "tdkAdaBtn";
            this.tdkAdaBtn.Size = new System.Drawing.Size(114, 100);
            this.tdkAdaBtn.TabIndex = 2;
            this.tdkAdaBtn.Text = "Ah ga ada !!!";
            this.tdkAdaBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.tdkAdaBtn.UseVisualStyleBackColor = true;
            this.tdkAdaBtn.Visible = false;
            this.tdkAdaBtn.Click += new System.EventHandler(this.tdkAdaBtn_Click);
            // 
            // adaBtn
            // 
            this.adaBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adaBtn.Image = global::TebakAngka.Properties.Resources.Select;
            this.adaBtn.Location = new System.Drawing.Point(14, 237);
            this.adaBtn.Name = "adaBtn";
            this.adaBtn.Size = new System.Drawing.Size(107, 100);
            this.adaBtn.TabIndex = 1;
            this.adaBtn.Text = "OK Lanjut !!!";
            this.adaBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.adaBtn.UseVisualStyleBackColor = true;
            this.adaBtn.Visible = false;
            this.adaBtn.Click += new System.EventHandler(this.adaBtn_Click);
            // 
            // tableNumber
            // 
            this.tableNumber.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableNumber.ColumnCount = 1;
            this.tableNumber.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableNumber.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableNumber.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableNumber.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableNumber.Location = new System.Drawing.Point(14, 21);
            this.tableNumber.Name = "tableNumber";
            this.tableNumber.RowCount = 1;
            this.tableNumber.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableNumber.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 199F));
            this.tableNumber.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 199F));
            this.tableNumber.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 199F));
            this.tableNumber.Size = new System.Drawing.Size(236, 200);
            this.tableNumber.TabIndex = 0;
            this.tableNumber.Visible = false;
            // 
            // partnerGroupBox
            // 
            this.partnerGroupBox.Controls.Add(this.partnerTextBox);
            this.partnerGroupBox.Location = new System.Drawing.Point(471, 12);
            this.partnerGroupBox.Name = "partnerGroupBox";
            this.partnerGroupBox.Size = new System.Drawing.Size(265, 165);
            this.partnerGroupBox.TabIndex = 5;
            this.partnerGroupBox.TabStop = false;
            this.partnerGroupBox.Text = "Pak Burung";
            // 
            // partnerTextBox
            // 
            this.partnerTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.partnerTextBox.Location = new System.Drawing.Point(6, 19);
            this.partnerTextBox.Multiline = true;
            this.partnerTextBox.Name = "partnerTextBox";
            this.partnerTextBox.Size = new System.Drawing.Size(253, 140);
            this.partnerTextBox.TabIndex = 0;
            // 
            // aboutBtn
            // 
            this.aboutBtn.BackgroundImage = global::TebakAngka.Properties.Resources.info;
            this.aboutBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.aboutBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.aboutBtn.Location = new System.Drawing.Point(376, 12);
            this.aboutBtn.Name = "aboutBtn";
            this.aboutBtn.Size = new System.Drawing.Size(89, 100);
            this.aboutBtn.TabIndex = 7;
            this.aboutBtn.Text = "About";
            this.aboutBtn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.aboutBtn.UseVisualStyleBackColor = true;
            this.aboutBtn.Click += new System.EventHandler(this.aboutBtn_Click);
            // 
            // logoPanel
            // 
            this.logoPanel.BackgroundImage = global::TebakAngka.Properties.Resources.TebakAngkaImg;
            this.logoPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.logoPanel.Location = new System.Drawing.Point(12, 12);
            this.logoPanel.Name = "logoPanel";
            this.logoPanel.Size = new System.Drawing.Size(358, 100);
            this.logoPanel.TabIndex = 6;
            // 
            // partnerPanel
            // 
            this.partnerPanel.BackgroundImage = global::TebakAngka.Properties.Resources.owl;
            this.partnerPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.partnerPanel.Location = new System.Drawing.Point(471, 183);
            this.partnerPanel.Name = "partnerPanel";
            this.partnerPanel.Size = new System.Drawing.Size(265, 284);
            this.partnerPanel.TabIndex = 3;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(747, 483);
            this.Controls.Add(this.aboutBtn);
            this.Controls.Add(this.logoPanel);
            this.Controls.Add(this.partnerGroupBox);
            this.Controls.Add(this.s);
            this.Controls.Add(this.partnerPanel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.Text = "Tebak Angka - Game Sederhana Untuk Siapa Saja ^^";
            this.s.ResumeLayout(false);
            this.partnerGroupBox.ResumeLayout(false);
            this.partnerGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel partnerPanel;
        private System.Windows.Forms.Panel s;
        private System.Windows.Forms.GroupBox partnerGroupBox;
        private System.Windows.Forms.TextBox partnerTextBox;
        private System.Windows.Forms.Panel logoPanel;
        private System.Windows.Forms.Button aboutBtn;
        private System.Windows.Forms.Button adaBtn;
        private System.Windows.Forms.TableLayoutPanel tableNumber;
        private System.Windows.Forms.Button tdkAdaBtn;
        private System.Windows.Forms.Button mulaiBtn;
        private System.Windows.Forms.Label mainLabel;
        private System.Windows.Forms.Button resetBtn;
    }
}

