﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/* ****************************************************
 * StepCollection       : Untuk menampung list dan manipulasi dari step step yang mungkin ada 
 * Author               : Bobby H 
 * Date                 : 20 July 2013 - 23 July 2013
 **************************************************** */
namespace TebakAngka.Control
{
    
    class StepCollection
    {
        private IStep prev;
        private List<IStep> steps;
        private int cursor;
        

        public StepCollection()
        {
            steps = new List<IStep>();
            steps.Add(new StartStep());
            steps.Add(new Step1());
            steps.Add(new Step2());
            steps.Add(new Step3());
            steps.Add(new Step4());
            steps.Add(new Step5());
            steps.Add(new EndStep());

            prev = null;
            cursor = 0;
        }

        public void resetPosition()
        {
            cursor = 0;
        }

        public Boolean isStartStep()
        {
            return (cursor == 0);
        }

        public Boolean isEndStep()
        {
            return (cursor == steps.Count - 1);
        }

        public IStep getPrevStep()
        {
            return prev;
        }

        public IStep getCurrStep()
        {
            return steps[cursor];
        }

        public IStep getNextStep()
        {
            IStep retval;
            if (cursor < 0)
            {
                prev = null;
            }
            else
            {
                prev = steps[cursor];
            }
            
            cursor++;
            if (cursor >= steps.Count())
            {
                retval = null;
            }
            else
            {
                retval = steps[cursor];
            }
           
          
           return retval;
        }

    }
}
