﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using TebakAngka.Control;
using System.Collections;
using System.Diagnostics;
using TebakAngka.GUI;

/* ****************************************************
 * MainForm             : Form utama aplikasi ini
 * Purpose              : Aplikasi ini dibuat untuk submit entry
 * http://programminglearning.wordpress.com/2013/07/18/lomba-membuat-game-sederhana-sesuai-contoh-level-pemula/
 * Author               : Bobby H 
 * Date                 : 20 July 2013 - 22 July 2013
 * Future Improvement   : Better algorithm (more dynamically & configurable)
 *                        Better UI
 *                        Mismatch fix
 *                
 **************************************************** */

namespace TebakAngka
{
    public partial class MainForm : Form
    {
        private StepCollection collection;
        private IStep currentStep;
        private List<int> pickConstanta;

        //Constructor class ini
        public MainForm()
        {
            InitializeComponent();
            startingDecorative();
            resetComponents();
            initStartComponent();
        }

        //Untuk mengatur tampilan awal 
        private void startingDecorative()
        {
            this.mainLabel.Visible = true;
            this.mulaiBtn.Visible = true;
            this.adaBtn.Visible = false;
            this.tdkAdaBtn.Visible = false;
            this.tableNumber.Visible = false;
            this.resetBtn.Visible = false;
        }

        //Untuk mengatur tampilan saat berlangsung game
        private void normalDecorative()
        {
            this.mainLabel.Visible = false;
            this.mulaiBtn.Visible = false;
            this.adaBtn.Visible = true;
            this.tdkAdaBtn.Visible = true;
            this.tableNumber.Visible = true;
            this.resetBtn.Visible = true;
        }

        //Initialize komponen awal, lebih tepatnya step awal
        private void initStartComponent()
        {
            currentStep = collection.getCurrStep();
            currentStep.playSound();
            currentStep.setMainDialog(mainLabel);
            currentStep.setPartnerDialogText(partnerTextBox);
        }

        //Flushing instance yang dipakai
        private void resetComponents()
        {
            collection = new StepCollection();
            pickConstanta = new List<int>();
            pickConstanta.Clear();
        }

        private void mulaiBtn_Click(object sender, EventArgs e)
        {
            resetComponents();
            initStartComponent();
            normalDecorative();
            collection.resetPosition();
            //Masuk step 1
            currentStep = collection.getNextStep();
            currentStep.playSound();
            currentStep.setMainDialog(mainLabel);
            currentStep.setPartnerDialogText(partnerTextBox);
            currentStep.generateNumberInBox(tableNumber);
            this.tdkAdaBtn.Visible = false;
        }

        private void adaBtn_Click(object sender, EventArgs e)
        {
            this.tdkAdaBtn.Visible = true;
            process(true);
        }

        private void tdkAdaBtn_Click(object sender, EventArgs e)
        {
            process(false);
        }

        private void process(Boolean responseFlag)
        {
            if (responseFlag)//Jika true maka yes button yang ditekan -> ambil constanta penambah
            {
                pickConstanta.Add(currentStep.getConstantaCount());
            }
            currentStep = collection.getNextStep();

            if (currentStep is EndStep)//End game detected, hitung constanta
            {
                currentStep.playSound();
                currentStep.countResult(pickConstanta);
                currentStep.setMainDialog(mainLabel);
                currentStep.setPartnerDialogText(partnerTextBox);
                startingDecorative();
            }
            else if (currentStep == null)// Game end, back to starting point --> reset semua
            {
                resetComponents();
                collection.resetPosition();
                initStartComponent();
                startingDecorative();

            }
            else //Normal handling
            {
                currentStep.playSound();
                currentStep.setMainDialog(mainLabel);
                currentStep.setPartnerDialogText(partnerTextBox);
                currentStep.generateNumberInBox(tableNumber);
            }
        }

        private void aboutBtn_Click(object sender, EventArgs e)
        {
            AboutForm about = new AboutForm();
            about.ShowDialog();
        }

        private void resetBtn_Click(object sender, EventArgs e)
        {
            resetComponents();
            collection.resetPosition();
            initStartComponent();
            startingDecorative();
        }

       
    }
}
