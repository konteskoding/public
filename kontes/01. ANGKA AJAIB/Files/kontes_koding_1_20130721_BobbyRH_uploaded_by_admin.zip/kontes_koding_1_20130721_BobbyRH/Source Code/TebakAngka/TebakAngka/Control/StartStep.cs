﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Media;

namespace TebakAngka.Control
{
    class StartStep : IStep
    {
        private String partnerDialog = "Halo, saya pak Burung akan menemani kamu " +
            "bermain, silakan tekan tombol mulai untuk bermain";
        private String lblDialog = "Silakan tekan tombol di bawah untuk mulai bermain";

        public void playSound()
        {
            try
            {
                SoundPlayer splayer = new SoundPlayer(TebakAngka.Properties.Resources.startDialog);
                splayer.Play();
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex);
            }

        }
        public void countResult(List<int> cons)
        {
            //Kosong karena tidak dibutuhkan hanya untuk kebutuhan implementasi interface
        }
        public int getConstantaCount()
        {
            return 0;
        }
        public void setPartnerDialogText(TextBox field)
        {
            field.Text = partnerDialog;
        }
        public Boolean generateNumberInBox(TableLayoutPanel table)
        {
            return true;
        }
        public void setMainDialog(Label lbl)
        {
            lbl.Text = lblDialog;
        }
    }
}
