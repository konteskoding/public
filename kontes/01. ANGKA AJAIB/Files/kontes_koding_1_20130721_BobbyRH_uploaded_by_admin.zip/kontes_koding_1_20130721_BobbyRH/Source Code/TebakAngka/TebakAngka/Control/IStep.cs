﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TebakAngka.Control
{
    /* Interface yang dipakai untuk step yang berlangsung
     * setPartnerDialogText : input text untuk pak Burung
     * generateNumberInBox  : menghasilkan angka di dalam tabel
     * setMainDialog        : untuk label utama
     * getCOnstantaCOunt    : ambil constanta untuk penambah hasil
     * countResult          : khusus untuk endStep, menghitung array constanta hasil 
     * getSoundPath         : ambil url path wav sound step yang bersangkutan
     */
    public interface IStep
    {
          void setPartnerDialogText(TextBox field);
          Boolean generateNumberInBox(TableLayoutPanel table);
          void setMainDialog(Label lbl);
          int getConstantaCount();
          void countResult(List<int> cons);
          void playSound();
    }
}
