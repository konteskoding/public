/**
 * Kelas utama. Digunakan untuk menjalankan program TebakAngka.
 * Program ini dibuat untuk kompetisi "Kontes Koding".
 * 
 * @author Affif Mukhlashin
 */
public class ActionTebakAngka {

    public static void main(String[] args) {
        
        /**
         * Program akan terus berjalan selama user belum memilih keluar.
         */
        do{
            /**
             * Membuat objek bertipe TebakAngka dengan tama ta.
             * @return object
             */
            TebakAngka ta = new TebakAngka();

            /**
             * Perulangan untuk menampilkan tabel 5 kali.
             */
            for (int i = 0; i < 5; i++) {
                // Cetak tabel.
                ta.printTable(i);
                // Ambil respon, hitung dan set hasil. 
                ta.setResult(ta.getResponse(), i);
            }
            // Cetak hasil.
            ta.printResult();
            // Apakah ingin main lagi?
            TebakAngka.getMainLagi();
        } while (TebakAngka.mainLagi == 'y');
        
    }
}