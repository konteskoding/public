import java.util.Scanner;

/**
 * Kelas TebakAngka. Digunakan untuk membuat objek 
 * TebakAngka pada kelas utama.
 * Program ini dibuat untuk kompetisi "Kontes Koding"
 * 
 * @author Affif Mukhlashin
 */
public class TebakAngka {

    /**
     * Variabel mainLagi bersifat static karena akan digunakan 
     * tanpa membuat objek terlebih dahulu.
     */
    public static char mainLagi;

    /**
     * variabel untuk menampung hasil tebakan
     */
    private int result;

    /**
     * Constructor
     * Menampilkan pesan pembuka ketika objek bertipe TebakAngka dibuat.
     */
    public TebakAngka() {
        System.out.println("===============Tebak angka===============");
        System.out.println("Bayangkan sebuah angka antara 1 sampai 31");
        System.out.println("Tekan enter jika sudah siap.");
        new Scanner(System.in).nextLine();
    }

    /**
     * mencetak tabel 4x4 
     * 
     * @param number nomer tabel yang akan dicetak.
     */
    public void printTable(int number) {
        /**
         * Membuat array table dengan isi 16.
         */
        int[] table = new int[16];

        /**
         * Digunakan sebagai index awal dari array table.
         */
        int index = 0;

        /**
         * Karena angka yang akan ditebak berada pada range 1-31, 
         * dan angka 31 besarnya 5 bit (11111), maka totalBit = 5.
         */
        int totalBit = 5;

        /**
         * Untuk menampung hasil konversi desimal ke binary.
         */
        String binary = "";

        /**
         * Perulangan untuk memasukkan hasil binary 5 bit ke dalam tabel.
         */
        for (int i = 1; i < 32; i++) {
            // Konversi desimal ke binary.
            binary = Integer.toBinaryString(i);

            /**
             * Perulangan untuk menambahkan 0 didepan angka jika hasil binary
             * kurang dari 5 bit.
             */
            for (int j = binary.length(); j < 5; j++) {
                binary = "0" + binary;
            }

            /**
             * Tabel 1 terdiri dari angka yang bit terakhir terdapat angka 1.
             * Tabel 2 terdiri dari angka yang bit kedua terdapat angka 1.
             * Jika dalam bit ke-n terdapat angka 1, maka angka tersebut dimasukkan
             * ke dalam array table.
             */
            if (binary.charAt(totalBit - (number+1)) == '1') {
                table[index] = i;
                index++;
            }
        }

        /**
         * Perulangan untuk mencetak tabel. Panjang tabel adalah 16
         * yang kemudian dipisah menjadi 4 baris.
         */
        for (int i = 0; i < table.length; i++) {
            /**
             * Jika nilai table[i] adalah satuan, maka cetak 1 spasi 
             * seletah pembatas '|' agar terlihat rapi.
             */
            if (table[i] < 10) {
                System.out.print("| " + table[i]);
            } else {
                System.out.print("|" + table[i]);
            }

            /**
             * Jika sudah 4 angka tercetak, maka cetak pembatas penutup
             * kemudian ganti baris.
             */
            if ((i + 1) % 4 == 0) {
                System.out.println("|");
            }
        }

    }

    /**
     * Mengambil respon dari user apakah angka yang dipilih 
     * ada pada tabel yang telah dicetak.
     * 
     * @return response Bernilai 'y' atau 'n'
     */
    public char getResponse() {
        Scanner input = new Scanner(System.in);
        char response = '0';
        do {
            System.out.print("Apakah angka pilihan anda terdapat pada tabel di atas?[y/n]");
            try {
                response = input.nextLine().charAt(0);
            } catch (Exception e) {
            }
        } while ((response != 'y') && (response != 'n'));

        return response;

    }

    /**
     * Memasukkan angka hasil tebakan.
     * @param  response
     * @param  i
     */
    public void setResult(char response, int i) {
        if (response == 'y') {
            /**
             * Hasil tebakan adalah penjumlahan dari 2^n
             * 
             */
            this.result = this.result + (int) Math.pow(2, i);
        }
    }

    /**
     * Mencetak hasil ke user
     */
    public void printResult() {
        /**
         * Jika hasil = 0, berarti angka yang dipilih bukan angka 1-31.
         * Jika tidak, tampilkan hasilnya ke user.
         */
        if (this.result == 0) {
            System.out.println("Angka yang ada dalam pikiran anda bukan diantara 1-31.");
        } else {
            System.out.println("Angka yang anda pilih adalah: " + this.result);
        }
    }

    /**
     * Apakah user ingin main lagi?
     * @return mainLagi dikembalikan untuk di proses pada do-while kelas utama
     */
    public static char getMainLagi() {
        Scanner input = new Scanner(System.in);
        do {
            System.out.print("Main lai?[y/n]");
            try {
                mainLagi = input.nextLine().charAt(0);
            } catch (Exception e) {
            }
        } while ((mainLagi != 'y') && (mainLagi != 'n'));

        return mainLagi;
    }
}