//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------


void __fastcall TForm1::Button1Click(TObject *Sender)
{
Command->Caption = "TutupMulai";
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Timer2Timer(TObject *Sender)
{
int a,b;

if(Command->Caption == "TutupMulai"){

        a = (0-Panel1->Width)/10;
        if(Panel1->Width > 0){
                Panel1->Width--;
                Panel1->Width+=a;
        }
        if(Panel1->Width==0){
                Command->Caption = "Command";
        }
}
if(Command->Caption == "BukaMulai"){

        a = (Form1->Width-Panel1->Width)/10;
        if(Panel1->Width < Form1->Width){
                Panel1->Width++;
                Panel1->Width+=a;
        }
        if(Panel1->Width==Form1->Width){
                T1->Left = 872;
                T2->Left = 880;
                T4->Left = 888;
                T8->Left = 896;
                T16->Left = 904;
                Command->Caption = "Command";
        }
}
if(Command->Caption == "T1Buka"){
        b = (0-T1->Left)/10;
        if(T1->Left>0){
                T1->Left+=b;
                T1->Left--;
                T1->Width++;
                T1->Width-=b;
        }
        if(T1->Left==0){
                Command->Caption = "Command";
        }
}
if(Command->Caption == "T1Tutup"){

        a = (8-T1->Width)/10;
        if(T1->Width > 8){
                T1->Width--;
                T1->Width+=a;

        }
        b = (8-T2->Left)/10;
        if(T2->Left>8){
                T2->Left+=b;
                T2->Left--;
                T2->Width++;
                T2->Width-=b;
        }
        if(T1->Width==8){
                Command->Caption = "Command";
        }
}
if(Command->Caption == "T2Tutup"){

        a = (8-T2->Width)/10;
        if(T2->Width > 8){
                T2->Width--;
                T2->Width+=a;

        }
        b = (16-T4->Left)/10;
        if(T4->Left>16){
                T4->Left+=b;
                T4->Left--;
                T4->Width++;
                T4->Width-=b;
        }
        if(T2->Width==8){
                Command->Caption = "Command";
        }
}
if(Command->Caption == "T4Tutup"){

        a = (8-T4->Width)/10;
        if(T4->Width > 8){
                T4->Width--;
                T4->Width+=a;

        }
        b = (24-T8->Left)/10;
        if(T8->Left>24){
                T8->Left+=b;
                T8->Left--;
                T8->Width++;
                T8->Width-=b;
        }
        if(T4->Width==8){
                Command->Caption = "Command";
        }
}
if(Command->Caption == "T8Tutup"){

        a = (8-T8->Width)/10;
        if(T8->Width > 8){
                T8->Width--;
                T8->Width+=a;

        }
        b = (32-T16->Left)/10;
        if(T16->Left>32){
                T16->Left+=b;
                T16->Left--;
                T16->Width++;
                T16->Width-=b;
        }
        if(T8->Width==8){
                Command->Caption = "Command";
        }
}
if(Command->Caption == "T16Tutup"){

        a = (8-T16->Width)/10;
        if(T16->Width > 8){
                T16->Width--;
                T16->Width+=a;

        }

        if(T16->Width==8){
                Tahasil->Caption = StrToInt(Ta1->Caption)+StrToInt(Ta2->Caption)+StrToInt(Ta4->Caption)+StrToInt(Ta8->Caption)+StrToInt(Ta16->Caption);
                Angka->Caption=Tahasil->Caption;
                Panel2->Show();
                Command->Caption = "Command";
        }
}
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button3Click(TObject *Sender)
{
Ta1->Caption = "1";
Command->Caption = "T1Tutup";
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button4Click(TObject *Sender)
{
Ta1->Caption = "0";
Command->Caption = "T1Tutup";
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button5Click(TObject *Sender)
{
Ta2->Caption = "2";
Command->Caption = "T2Tutup";
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button6Click(TObject *Sender)
{
Ta2->Caption = "0";
Command->Caption = "T2Tutup";       
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button7Click(TObject *Sender)
{
Ta4->Caption = "4";
Command->Caption = "T4Tutup";
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button8Click(TObject *Sender)
{
Ta4->Caption = "0";
Command->Caption = "T4Tutup";
}
//---------------------------------------------------------------------------


void __fastcall TForm1::Button9Click(TObject *Sender)
{
Ta8->Caption = "8";
Command->Caption = "T8Tutup";
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button10Click(TObject *Sender)
{
Ta8->Caption = "0";
Command->Caption = "T8Tutup";
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button11Click(TObject *Sender)
{
Ta16->Caption = "16";
Command->Caption = "T16Tutup";
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button12Click(TObject *Sender)
{
Ta16->Caption = "0";
Command->Caption = "T16Tutup";    
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button13Click(TObject *Sender)
{
Panel2->Visible = false;
Command->Caption = "BukaMulai";
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button2Click(TObject *Sender)
{
Command->Caption = "T1Buka";
}
//---------------------------------------------------------------------------

