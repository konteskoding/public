<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pb1 = New System.Windows.Forms.PictureBox
        Me.pb2 = New System.Windows.Forms.PictureBox
        Me.pb4 = New System.Windows.Forms.PictureBox
        Me.pb8 = New System.Windows.Forms.PictureBox
        Me.pb16 = New System.Windows.Forms.PictureBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Button1 = New System.Windows.Forms.Button
        Me.Button2 = New System.Windows.Forms.Button
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.Panel3 = New System.Windows.Forms.Panel
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        CType(Me.pb1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb16, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'pb1
        '
        Me.pb1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pb1.Image = Global.TebakAngka.My.Resources.Resources._1
        Me.pb1.Location = New System.Drawing.Point(0, 0)
        Me.pb1.Name = "pb1"
        Me.pb1.Size = New System.Drawing.Size(461, 312)
        Me.pb1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pb1.TabIndex = 0
        Me.pb1.TabStop = False
        '
        'pb2
        '
        Me.pb2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pb2.Image = Global.TebakAngka.My.Resources.Resources._2
        Me.pb2.Location = New System.Drawing.Point(0, 0)
        Me.pb2.Name = "pb2"
        Me.pb2.Size = New System.Drawing.Size(461, 312)
        Me.pb2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pb2.TabIndex = 1
        Me.pb2.TabStop = False
        '
        'pb4
        '
        Me.pb4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pb4.Image = Global.TebakAngka.My.Resources.Resources._4
        Me.pb4.Location = New System.Drawing.Point(0, 0)
        Me.pb4.Name = "pb4"
        Me.pb4.Size = New System.Drawing.Size(461, 312)
        Me.pb4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pb4.TabIndex = 2
        Me.pb4.TabStop = False
        '
        'pb8
        '
        Me.pb8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pb8.Image = Global.TebakAngka.My.Resources.Resources._8
        Me.pb8.InitialImage = Global.TebakAngka.My.Resources.Resources._8
        Me.pb8.Location = New System.Drawing.Point(0, 0)
        Me.pb8.Name = "pb8"
        Me.pb8.Size = New System.Drawing.Size(461, 312)
        Me.pb8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pb8.TabIndex = 3
        Me.pb8.TabStop = False
        '
        'pb16
        '
        Me.pb16.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pb16.Image = Global.TebakAngka.My.Resources.Resources._16
        Me.pb16.Location = New System.Drawing.Point(0, 0)
        Me.pb16.Name = "pb16"
        Me.pb16.Size = New System.Drawing.Size(461, 312)
        Me.pb16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pb16.TabIndex = 4
        Me.pb16.TabStop = False
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Monotype Corsiva", 14.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Red
        Me.Label4.Location = New System.Drawing.Point(94, 335)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(290, 25)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Apakah anda sudah menentukan pilihan anda? "
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Lucida Sans Unicode", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(26, 372)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(206, 35)
        Me.Button1.TabIndex = 6
        Me.Button1.Text = "Ya, Lanjutkan"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Lucida Sans Unicode", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(252, 372)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(208, 35)
        Me.Button2.TabIndex = 6
        Me.Button2.Text = "Tidak, Terima kasih"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(461, 312)
        Me.Panel1.TabIndex = 7
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Monotype Corsiva", 15.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Green
        Me.Label3.Location = New System.Drawing.Point(19, 197)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(428, 60)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Tentukan pilihan anda dengan jujur dan hati nurani :) dan ingat baik-baik bila pe" & _
            "rlu dicatat !"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Monotype Corsiva", 15.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Magenta
        Me.Label2.Location = New System.Drawing.Point(16, 120)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(261, 25)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Pilihlah satu dari angka 1 - 31 ..."
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Monotype Corsiva", 27.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Blue
        Me.Label1.Location = New System.Drawing.Point(16, 21)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(195, 45)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Tebak Angka"
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.Panel2)
        Me.Panel3.Controls.Add(Me.Panel1)
        Me.Panel3.Controls.Add(Me.pb1)
        Me.Panel3.Controls.Add(Me.pb2)
        Me.Panel3.Controls.Add(Me.pb4)
        Me.Panel3.Controls.Add(Me.pb8)
        Me.Panel3.Controls.Add(Me.pb16)
        Me.Panel3.Location = New System.Drawing.Point(12, 12)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(461, 312)
        Me.Panel3.TabIndex = 10
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Controls.Add(Me.Label5)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(461, 312)
        Me.Panel2.TabIndex = 8
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Monotype Corsiva", 48.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Blue
        Me.Label6.Location = New System.Drawing.Point(61, 108)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(335, 92)
        Me.Label6.TabIndex = 8
        Me.Label6.Text = "Angka "
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Monotype Corsiva", 20.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.HotPink
        Me.Label5.Location = New System.Drawing.Point(64, 47)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(325, 35)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Angka yang anda pilih adalah ..."
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(485, 419)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label4)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.Text = "Tebak Angka"
        CType(Me.pb1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb16, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pb1 As System.Windows.Forms.PictureBox
    Friend WithEvents pb2 As System.Windows.Forms.PictureBox
    Friend WithEvents pb4 As System.Windows.Forms.PictureBox
    Friend WithEvents pb8 As System.Windows.Forms.PictureBox
    Friend WithEvents pb16 As System.Windows.Forms.PictureBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Panel3 As System.Windows.Forms.Panel

End Class
