'program sederhana ini dibuat oleh Akhmad Sehabudin
'ahabasgar@yahoo.com
'dibuat untuk sebagai jawaban atas kuis dari alamat situ
'http://programminglearning.wordpress.com/2013/07/18/lomba-membuat-game-sederhana-sesuai-contoh-level-pemula/


Public Class Form1
    Dim iState As Integer
    Dim iPilihan As Integer
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Panel1.Visible = True
        hide_table()
        Panel2.Visible = False
        Label4.Text = "Apakah anda sudah menentukan pilihan ?"
        Button1.Text = "Ya, lanjutkan"
        Button2.Text = "Tidak, terima kasih"
        iState = 0
        iPilihan = 0
    End Sub
    Private Sub hide_table()
        pb1.Visible = False
        pb2.Visible = False
        pb4.Visible = False
        pb8.Visible = False
        pb16.Visible = False
    End Sub
    Private Sub cek_angka()
        If iState < 6 Then
            Label4.Text = "Apakah angka yang anda pilih ada disini ?"
        Else
            Label4.Text = "Apakah ingin mencoba lagi?"
            Button1.Text = "Ya, Coba lagi"
            Button2.Text = "Tidak, Terima kasih"
        End If
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Button1.Text = "Ada"
        Button2.Text = "Tidak"
        Panel1.Visible = False
        hide_table()
        Select Case iState
            Case 0
                pb1.Visible = True
            Case 1
                pb2.Visible = True
                iPilihan = iPilihan + 1
            Case 2
                pb4.Visible = True
                iPilihan = iPilihan + 2
            Case 3
                pb8.Visible = True
                iPilihan = iPilihan + 4
            Case 4
                pb16.Visible = True
                iPilihan = iPilihan + 8
            Case 5
                Panel2.Visible = True
                iPilihan = iPilihan + 16
                Label6.Text = "Angka " & iPilihan
            Case 6
                Form1_Load(sender, e)
                Exit Sub
        End Select
        iState = iState + 1
        cek_angka()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Button1.Text = "Ada"
        Button2.Text = "Tidak"
        hide_table()
        Select Case iState
            Case 0
                Close()
            Case 1
                pb2.Visible = True
            Case 2
                pb4.Visible = True
            Case 3
                pb8.Visible = True
            Case 4
                pb16.Visible = True
            Case 5
                Panel2.Visible = True
                If iPilihan > 0 Then
                    Label6.Text = "Angka " & iPilihan
                Else
                    Label6.Text = "Tidak Ada"
                End If
            Case 6
                Close()
        End Select
        iState = iState + 1
        cek_angka()
    End Sub


End Class
