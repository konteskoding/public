Bahasa Pemrograman : C#
Kebutuhan Progam : .Net Framework Client 4.5

Nama : Ahmad Sholikin (WMTC)
Email : gbr_astina@live.com
FB : www.facebook.com/gbr.astina?ref=tn_tnmn
Twitter : @gbr_ak47
Bahasa : Jawa, Indonesia

video demo : http://youtu.be/sdlACAH1EVk