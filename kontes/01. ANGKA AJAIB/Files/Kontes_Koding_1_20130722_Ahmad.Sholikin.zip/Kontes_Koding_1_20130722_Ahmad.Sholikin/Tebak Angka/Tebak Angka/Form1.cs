﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Tebak_Angka
{
    public partial class logo : Form
    {
        
        // pembuatan variabel
        int jawaban = 0;
        
        public logo()
        {
            InitializeComponent();
        }

        private void help_Click(object sender, EventArgs e)
        {
            // pengaturan UI
            bantuan.Visible = true;
            gameplay.Visible = false;
            ya.Visible = false;
            no.Visible = false;
            tebakangka.Visible = false;
            develop.Visible = false;
        }

        private void keluar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void mulai_Click(object sender, EventArgs e)
        {
            // nilai awal
            jawaban = 0;
            // pengaturan UI
            
            mulai.Enabled = false;
            ulangi.Enabled = true;
            gameplay.Visible = true;
            bantuan.Visible = true;
            ya.Visible = true;
            no.Visible = true;
            bantuan.Visible = false;
            tebakangka.Visible = false;
            develop.Visible = false;

            // manggil fungsi
            tabel1();

            // untuk mendapatkan langkah pertabel dan nilai yang dibayangkan
            inisialisasi.Text = "1";
            hasil.Text = "0";
        }

        private void ulangi_Click(object sender, EventArgs e)
        {
            mulai_Click(sender,e);
        }

        // logika

        public void tabel1()
        {
            // pengaturan daftar list angka
            
            // baris pertama
            a1.Text = "1";
            a2.Text = "3";
            a3.Text = "5";
            a4.Text = "7";

            // baris kedua
            b1.Text = "9";
            b2.Text = "11";
            b3.Text = "13";
            b4.Text = "15";

            // baris ketiga
            c1.Text = "17";
            c2.Text = "19";
            c3.Text = "21";
            c4.Text = "23";

            //baris keempat
            d1.Text = "25";
            d2.Text = "27";
            d3.Text = "29";
            d4.Text = "31";
        }

        public void tabel2()
        {
            // pengaturan daftar list angka

            // baris pertama
            a1.Text = "2";
            a2.Text = "3";
            a3.Text = "6";
            a4.Text = "7";

            // baris kedua
            b1.Text = "10";
            b2.Text = "11";
            b3.Text = "14";
            b4.Text = "15";

            // baris ketiga
            c1.Text = "18";
            c2.Text = "19";
            c3.Text = "22";
            c4.Text = "23";

            //baris keempat
            d1.Text = "26";
            d2.Text = "27";
            d3.Text = "30";
            d4.Text = "31";
        }

        public void tabel3()
        {
            // pengaturan daftar list angka

            // baris pertama
            a1.Text = "4";
            a2.Text = "5";
            a3.Text = "6";
            a4.Text = "7";

            // baris kedua
            b1.Text = "12";
            b2.Text = "13";
            b3.Text = "14";
            b4.Text = "15";

            // baris ketiga
            c1.Text = "20";
            c2.Text = "21";
            c3.Text = "22";
            c4.Text = "23";

            //baris keempat
            d1.Text = "28";
            d2.Text = "29";
            d3.Text = "30";
            d4.Text = "31";
        }

        public void tabel4()
        {
            // pengaturan daftar list angka

            // baris pertama
            a1.Text = "8";
            a2.Text = "9";
            a3.Text = "10";
            a4.Text = "11";

            // baris kedua
            b1.Text = "12";
            b2.Text = "13";
            b3.Text = "14";
            b4.Text = "15";

            // baris ketiga
            c1.Text = "24";
            c2.Text = "25";
            c3.Text = "26";
            c4.Text = "27";

            //baris keempat
            d1.Text = "28";
            d2.Text = "29";
            d3.Text = "30";
            d4.Text = "31";
        }

        public void tabel5()
        {
            // pengaturan daftar list angka

            // baris pertama
            a1.Text = "16";
            a2.Text = "17";
            a3.Text = "18";
            a4.Text = "19";

            // baris kedua
            b1.Text = "20";
            b2.Text = "21";
            b3.Text = "22";
            b4.Text = "23";

            // baris ketiga
            c1.Text = "24";
            c2.Text = "25";
            c3.Text = "26";
            c4.Text = "27";

            //baris keempat
            d1.Text = "28";
            d2.Text = "29";
            d3.Text = "30";
            d4.Text = "31";
        }

        public void tabel6()
        {
            // pengaturan daftar list angka

            // baris pertama
            a1.Text = "32";
            a2.Text = "33";
            a3.Text = "34";
            a4.Text = "35";

            // baris kedua
            b1.Text = "36";
            b2.Text = "37";
            b3.Text = "38";
            b4.Text = "39";

            // baris ketiga
            c1.Text = "40";
            c2.Text = "41";
            c3.Text = "42";
            c4.Text = "43";

            //baris keempat
            d1.Text = "44";
            d2.Text = "45";
            d3.Text = "46";
            d4.Text = "47";
        }

        public void angkakeluar()
        {
            if((jawaban==0)||(jawaban>32))
            {
                ulangi.Enabled = false;
                mulai.Enabled = true;
                gameplay.Visible = false;
                ya.Visible = false;
                no.Visible = false;
                MessageBox.Show("Hey, ini kan permainan tebak angka, kenapa kamu tidak membayangkan angkanya ?","Peringatan");
            }

            else
            {
                ulangi.Enabled = false;
                mulai.Enabled = true;
                gameplay.Visible = false;
                ya.Visible = false;
                no.Visible = false;
                MessageBox.Show("Angka yang kamu pilih adalah "+hasil.Text,"Hasil");
            }

            tebakangka.Visible = true;
            develop.Visible = true;
        }

        private void ya_Click(object sender, EventArgs e)
        {
            if (inisialisasi.Text == "1")
            {
                tabel2();
                inisialisasi.Text = "2";
                jawaban += 1;
            }

            else if (inisialisasi.Text == "2")
            {
                tabel3();
                inisialisasi.Text = "3";
                jawaban += 2;
            }

            else if (inisialisasi.Text == "3")
            {
                tabel4();
                inisialisasi.Text = "4";
                jawaban += 4;
            }

            else if (inisialisasi.Text == "4")
            {
                tabel5();
                inisialisasi.Text = "5";
                jawaban += 8;
            }

            else if (inisialisasi.Text == "5")
            {
                tabel6();
                inisialisasi.Text = "6";
                jawaban += 16;
            }

            else if (inisialisasi.Text == "6")
            {
                jawaban += 32;
                if (jawaban > 32)
                {
                    MessageBox.Show("Hey, ini kan permainan tebak angka, kenapa kamu tidak membayangkan angkanya ?", "Peringatan");
                }
                else
                {
                    MessageBox.Show("Angka yang kamu pilih adalah 32", "Hasil");
                }
                inisialisasi.Text = "0";
                ulangi.Enabled = false;
                mulai.Enabled = true;
                gameplay.Visible = false;
                ya.Visible = false;
                no.Visible = false;
                tebakangka.Visible = true;
                develop.Visible = true;
                
            }

            hasil.Text = jawaban.ToString();

        }

        private void no_Click(object sender, EventArgs e)
        {
            if (inisialisasi.Text == "1")
            {
                tabel2();
                inisialisasi.Text = "2";
                jawaban += 0;
            }

            else if (inisialisasi.Text == "2")
            {
                tabel3();
                inisialisasi.Text = "3";
                jawaban += 0;
            }

            else if (inisialisasi.Text == "3")
            {
                tabel4();
                inisialisasi.Text = "4";
                jawaban += 0;
            }

            else if (inisialisasi.Text == "4")
            {
                tabel5();
                inisialisasi.Text = "5";
                jawaban += 0;
            }

            else if (inisialisasi.Text == "5")
            {
                tabel6();
                inisialisasi.Text = "6";
                jawaban += 0;
            }


            else if (inisialisasi.Text == "6")
            {
                angkakeluar();
                inisialisasi.Text = "6";
                jawaban += 0;
            }

            hasil.Text = jawaban.ToString();
        }

    }
}
