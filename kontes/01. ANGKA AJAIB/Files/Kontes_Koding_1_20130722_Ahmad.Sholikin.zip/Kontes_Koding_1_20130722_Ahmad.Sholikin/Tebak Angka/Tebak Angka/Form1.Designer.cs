﻿namespace Tebak_Angka
{
    partial class logo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(logo));
            this.gameplay = new System.Windows.Forms.GroupBox();
            this.d4 = new System.Windows.Forms.Label();
            this.d3 = new System.Windows.Forms.Label();
            this.d2 = new System.Windows.Forms.Label();
            this.d1 = new System.Windows.Forms.Label();
            this.c4 = new System.Windows.Forms.Label();
            this.c3 = new System.Windows.Forms.Label();
            this.c2 = new System.Windows.Forms.Label();
            this.c1 = new System.Windows.Forms.Label();
            this.b4 = new System.Windows.Forms.Label();
            this.b3 = new System.Windows.Forms.Label();
            this.b2 = new System.Windows.Forms.Label();
            this.b1 = new System.Windows.Forms.Label();
            this.a4 = new System.Windows.Forms.Label();
            this.a3 = new System.Windows.Forms.Label();
            this.a2 = new System.Windows.Forms.Label();
            this.a1 = new System.Windows.Forms.Label();
            this.ya = new System.Windows.Forms.Button();
            this.no = new System.Windows.Forms.Button();
            this.bantuan = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mulai = new System.Windows.Forms.ToolStripMenuItem();
            this.ulangi = new System.Windows.Forms.ToolStripMenuItem();
            this.keluar = new System.Windows.Forms.ToolStripMenuItem();
            this.bantuanToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.help = new System.Windows.Forms.ToolStripMenuItem();
            this.inisialisasi = new System.Windows.Forms.TextBox();
            this.hasil = new System.Windows.Forms.TextBox();
            this.tebakangka = new System.Windows.Forms.Label();
            this.develop = new System.Windows.Forms.Label();
            this.gameplay.SuspendLayout();
            this.bantuan.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // gameplay
            // 
            this.gameplay.BackColor = System.Drawing.Color.Transparent;
            this.gameplay.Controls.Add(this.d4);
            this.gameplay.Controls.Add(this.d3);
            this.gameplay.Controls.Add(this.d2);
            this.gameplay.Controls.Add(this.d1);
            this.gameplay.Controls.Add(this.c4);
            this.gameplay.Controls.Add(this.c3);
            this.gameplay.Controls.Add(this.c2);
            this.gameplay.Controls.Add(this.c1);
            this.gameplay.Controls.Add(this.b4);
            this.gameplay.Controls.Add(this.b3);
            this.gameplay.Controls.Add(this.b2);
            this.gameplay.Controls.Add(this.b1);
            this.gameplay.Controls.Add(this.a4);
            this.gameplay.Controls.Add(this.a3);
            this.gameplay.Controls.Add(this.a2);
            this.gameplay.Controls.Add(this.a1);
            this.gameplay.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gameplay.Location = new System.Drawing.Point(12, 31);
            this.gameplay.Name = "gameplay";
            this.gameplay.Size = new System.Drawing.Size(260, 199);
            this.gameplay.TabIndex = 0;
            this.gameplay.TabStop = false;
            this.gameplay.Text = " Apakah angkanya ada disini ? ";
            this.gameplay.Visible = false;
            // 
            // d4
            // 
            this.d4.AutoSize = true;
            this.d4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.d4.ForeColor = System.Drawing.Color.Orange;
            this.d4.Location = new System.Drawing.Point(196, 149);
            this.d4.Name = "d4";
            this.d4.Size = new System.Drawing.Size(41, 29);
            this.d4.TabIndex = 15;
            this.d4.Text = "16";
            // 
            // d3
            // 
            this.d3.AutoSize = true;
            this.d3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.d3.ForeColor = System.Drawing.SystemColors.GrayText;
            this.d3.Location = new System.Drawing.Point(135, 149);
            this.d3.Name = "d3";
            this.d3.Size = new System.Drawing.Size(41, 29);
            this.d3.TabIndex = 14;
            this.d3.Text = "15";
            // 
            // d2
            // 
            this.d2.AutoSize = true;
            this.d2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.d2.ForeColor = System.Drawing.Color.Orange;
            this.d2.Location = new System.Drawing.Point(78, 149);
            this.d2.Name = "d2";
            this.d2.Size = new System.Drawing.Size(41, 29);
            this.d2.TabIndex = 13;
            this.d2.Text = "14";
            // 
            // d1
            // 
            this.d1.AutoSize = true;
            this.d1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.d1.ForeColor = System.Drawing.SystemColors.GrayText;
            this.d1.Location = new System.Drawing.Point(21, 149);
            this.d1.Name = "d1";
            this.d1.Size = new System.Drawing.Size(41, 29);
            this.d1.TabIndex = 12;
            this.d1.Text = "13";
            // 
            // c4
            // 
            this.c4.AutoSize = true;
            this.c4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c4.ForeColor = System.Drawing.Color.Orange;
            this.c4.Location = new System.Drawing.Point(196, 109);
            this.c4.Name = "c4";
            this.c4.Size = new System.Drawing.Size(41, 29);
            this.c4.TabIndex = 11;
            this.c4.Text = "12";
            // 
            // c3
            // 
            this.c3.AutoSize = true;
            this.c3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c3.ForeColor = System.Drawing.SystemColors.GrayText;
            this.c3.Location = new System.Drawing.Point(135, 109);
            this.c3.Name = "c3";
            this.c3.Size = new System.Drawing.Size(41, 29);
            this.c3.TabIndex = 10;
            this.c3.Text = "11";
            // 
            // c2
            // 
            this.c2.AutoSize = true;
            this.c2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c2.ForeColor = System.Drawing.Color.Orange;
            this.c2.Location = new System.Drawing.Point(78, 109);
            this.c2.Name = "c2";
            this.c2.Size = new System.Drawing.Size(41, 29);
            this.c2.TabIndex = 9;
            this.c2.Text = "11";
            // 
            // c1
            // 
            this.c1.AutoSize = true;
            this.c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.c1.ForeColor = System.Drawing.SystemColors.GrayText;
            this.c1.Location = new System.Drawing.Point(21, 109);
            this.c1.Name = "c1";
            this.c1.Size = new System.Drawing.Size(41, 29);
            this.c1.TabIndex = 8;
            this.c1.Text = "11";
            // 
            // b4
            // 
            this.b4.AutoSize = true;
            this.b4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b4.ForeColor = System.Drawing.Color.Orange;
            this.b4.Location = new System.Drawing.Point(196, 71);
            this.b4.Name = "b4";
            this.b4.Size = new System.Drawing.Size(41, 29);
            this.b4.TabIndex = 7;
            this.b4.Text = "11";
            this.b4.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // b3
            // 
            this.b3.AutoSize = true;
            this.b3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b3.ForeColor = System.Drawing.SystemColors.GrayText;
            this.b3.Location = new System.Drawing.Point(135, 71);
            this.b3.Name = "b3";
            this.b3.Size = new System.Drawing.Size(41, 29);
            this.b3.TabIndex = 6;
            this.b3.Text = "11";
            this.b3.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // b2
            // 
            this.b2.AutoSize = true;
            this.b2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b2.ForeColor = System.Drawing.Color.Orange;
            this.b2.Location = new System.Drawing.Point(78, 71);
            this.b2.Name = "b2";
            this.b2.Size = new System.Drawing.Size(41, 29);
            this.b2.TabIndex = 5;
            this.b2.Text = "11";
            this.b2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // b1
            // 
            this.b1.AutoSize = true;
            this.b1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b1.ForeColor = System.Drawing.SystemColors.GrayText;
            this.b1.Location = new System.Drawing.Point(21, 71);
            this.b1.Name = "b1";
            this.b1.Size = new System.Drawing.Size(41, 29);
            this.b1.TabIndex = 4;
            this.b1.Text = "11";
            this.b1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // a4
            // 
            this.a4.AutoSize = true;
            this.a4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.a4.ForeColor = System.Drawing.Color.Orange;
            this.a4.Location = new System.Drawing.Point(196, 33);
            this.a4.Name = "a4";
            this.a4.Size = new System.Drawing.Size(41, 29);
            this.a4.TabIndex = 3;
            this.a4.Text = "11";
            // 
            // a3
            // 
            this.a3.AutoSize = true;
            this.a3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.a3.ForeColor = System.Drawing.SystemColors.GrayText;
            this.a3.Location = new System.Drawing.Point(135, 33);
            this.a3.Name = "a3";
            this.a3.Size = new System.Drawing.Size(41, 29);
            this.a3.TabIndex = 2;
            this.a3.Text = "11";
            // 
            // a2
            // 
            this.a2.AutoSize = true;
            this.a2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.a2.ForeColor = System.Drawing.Color.Orange;
            this.a2.Location = new System.Drawing.Point(78, 33);
            this.a2.Name = "a2";
            this.a2.Size = new System.Drawing.Size(41, 29);
            this.a2.TabIndex = 1;
            this.a2.Text = "11";
            // 
            // a1
            // 
            this.a1.AutoSize = true;
            this.a1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.a1.ForeColor = System.Drawing.SystemColors.GrayText;
            this.a1.Location = new System.Drawing.Point(21, 33);
            this.a1.Name = "a1";
            this.a1.Size = new System.Drawing.Size(41, 29);
            this.a1.TabIndex = 0;
            this.a1.Text = "11";
            // 
            // ya
            // 
            this.ya.BackColor = System.Drawing.SystemColors.Highlight;
            this.ya.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ya.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ya.Location = new System.Drawing.Point(116, 236);
            this.ya.Name = "ya";
            this.ya.Size = new System.Drawing.Size(75, 31);
            this.ya.TabIndex = 16;
            this.ya.TabStop = false;
            this.ya.Text = "Ya";
            this.ya.UseVisualStyleBackColor = false;
            this.ya.Visible = false;
            this.ya.Click += new System.EventHandler(this.ya_Click);
            // 
            // no
            // 
            this.no.BackColor = System.Drawing.SystemColors.Highlight;
            this.no.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.no.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.no.Location = new System.Drawing.Point(198, 237);
            this.no.Name = "no";
            this.no.Size = new System.Drawing.Size(75, 30);
            this.no.TabIndex = 17;
            this.no.TabStop = false;
            this.no.Text = "Tidak";
            this.no.UseVisualStyleBackColor = false;
            this.no.Visible = false;
            this.no.Click += new System.EventHandler(this.no_Click);
            // 
            // bantuan
            // 
            this.bantuan.BackColor = System.Drawing.Color.Transparent;
            this.bantuan.Controls.Add(this.label1);
            this.bantuan.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bantuan.Location = new System.Drawing.Point(12, 31);
            this.bantuan.Name = "bantuan";
            this.bantuan.Size = new System.Drawing.Size(260, 236);
            this.bantuan.TabIndex = 18;
            this.bantuan.TabStop = false;
            this.bantuan.Text = "Cara Bermain";
            this.bantuan.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(11, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(245, 195);
            this.label1.TabIndex = 0;
            this.label1.Text = resources.GetString("label1.Text");
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Transparent;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuToolStripMenuItem,
            this.bantuanToolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(284, 24);
            this.menuStrip1.TabIndex = 19;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // menuToolStripMenuItem
            // 
            this.menuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mulai,
            this.ulangi,
            this.keluar});
            this.menuToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlText;
            this.menuToolStripMenuItem.Name = "menuToolStripMenuItem";
            this.menuToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.menuToolStripMenuItem.Text = "Menu";
            // 
            // mulai
            // 
            this.mulai.Name = "mulai";
            this.mulai.ShortcutKeys = System.Windows.Forms.Keys.F1;
            this.mulai.Size = new System.Drawing.Size(149, 22);
            this.mulai.Text = "Mulai";
            this.mulai.Click += new System.EventHandler(this.mulai_Click);
            // 
            // ulangi
            // 
            this.ulangi.Enabled = false;
            this.ulangi.Name = "ulangi";
            this.ulangi.ShortcutKeys = System.Windows.Forms.Keys.F2;
            this.ulangi.Size = new System.Drawing.Size(149, 22);
            this.ulangi.Text = "Ulangi";
            this.ulangi.Click += new System.EventHandler(this.ulangi_Click);
            // 
            // keluar
            // 
            this.keluar.Name = "keluar";
            this.keluar.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this.keluar.Size = new System.Drawing.Size(149, 22);
            this.keluar.Text = "Keluar";
            this.keluar.Click += new System.EventHandler(this.keluar_Click);
            // 
            // bantuanToolStripMenuItem1
            // 
            this.bantuanToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.help});
            this.bantuanToolStripMenuItem1.Name = "bantuanToolStripMenuItem1";
            this.bantuanToolStripMenuItem1.Size = new System.Drawing.Size(63, 20);
            this.bantuanToolStripMenuItem1.Text = "Bantuan";
            // 
            // help
            // 
            this.help.Name = "help";
            this.help.Size = new System.Drawing.Size(145, 22);
            this.help.Text = "Cara Bermain";
            this.help.Click += new System.EventHandler(this.help_Click);
            // 
            // inisialisasi
            // 
            this.inisialisasi.Location = new System.Drawing.Point(13, 242);
            this.inisialisasi.Name = "inisialisasi";
            this.inisialisasi.Size = new System.Drawing.Size(34, 20);
            this.inisialisasi.TabIndex = 20;
            this.inisialisasi.Visible = false;
            // 
            // hasil
            // 
            this.hasil.Location = new System.Drawing.Point(53, 242);
            this.hasil.Name = "hasil";
            this.hasil.Size = new System.Drawing.Size(34, 20);
            this.hasil.TabIndex = 21;
            this.hasil.Visible = false;
            // 
            // tebakangka
            // 
            this.tebakangka.AutoSize = true;
            this.tebakangka.BackColor = System.Drawing.Color.Transparent;
            this.tebakangka.Font = new System.Drawing.Font("Segoe UI Semibold", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tebakangka.ForeColor = System.Drawing.Color.Maroon;
            this.tebakangka.Location = new System.Drawing.Point(25, 85);
            this.tebakangka.Name = "tebakangka";
            this.tebakangka.Size = new System.Drawing.Size(218, 46);
            this.tebakangka.TabIndex = 22;
            this.tebakangka.Text = "Tebak Angka";
            // 
            // develop
            // 
            this.develop.AutoSize = true;
            this.develop.BackColor = System.Drawing.Color.Transparent;
            this.develop.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.develop.ForeColor = System.Drawing.SystemColors.GrayText;
            this.develop.Location = new System.Drawing.Point(85, 130);
            this.develop.Name = "develop";
            this.develop.Size = new System.Drawing.Size(144, 15);
            this.develop.TabIndex = 23;
            this.develop.Text = "Developed by WMTC 2013";
            // 
            // logo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BackgroundImage = global::Tebak_Angka.Properties.Resources.all_halaman2;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(284, 280);
            this.Controls.Add(this.develop);
            this.Controls.Add(this.tebakangka);
            this.Controls.Add(this.hasil);
            this.Controls.Add(this.inisialisasi);
            this.Controls.Add(this.bantuan);
            this.Controls.Add(this.no);
            this.Controls.Add(this.ya);
            this.Controls.Add(this.gameplay);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "logo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tebak Angka";
            this.gameplay.ResumeLayout(false);
            this.gameplay.PerformLayout();
            this.bantuan.ResumeLayout(false);
            this.bantuan.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gameplay;
        private System.Windows.Forms.Label d4;
        private System.Windows.Forms.Label d3;
        private System.Windows.Forms.Label d2;
        private System.Windows.Forms.Label d1;
        private System.Windows.Forms.Label c4;
        private System.Windows.Forms.Label c3;
        private System.Windows.Forms.Label c2;
        private System.Windows.Forms.Label c1;
        private System.Windows.Forms.Label b4;
        private System.Windows.Forms.Label b3;
        private System.Windows.Forms.Label b2;
        private System.Windows.Forms.Label b1;
        private System.Windows.Forms.Label a4;
        private System.Windows.Forms.Label a3;
        private System.Windows.Forms.Label a2;
        private System.Windows.Forms.Label a1;
        private System.Windows.Forms.Button ya;
        private System.Windows.Forms.Button no;
        private System.Windows.Forms.GroupBox bantuan;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem menuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mulai;
        private System.Windows.Forms.ToolStripMenuItem ulangi;
        private System.Windows.Forms.ToolStripMenuItem keluar;
        private System.Windows.Forms.ToolStripMenuItem bantuanToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem help;
        private System.Windows.Forms.TextBox inisialisasi;
        private System.Windows.Forms.TextBox hasil;
        private System.Windows.Forms.Label tebakangka;
        private System.Windows.Forms.Label develop;
    }
}

